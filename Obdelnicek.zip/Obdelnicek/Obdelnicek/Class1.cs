﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Obdelnicek
{
    class Obdelnik
    {
        private double _stranaA;
        private double _stranaB;

        public double stranaA
        {
            set
            {
                if (value >= 0)
                {
                    _stranaA = stranaA;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("Zaporne cislo");
                }
            }
            get
            {
                return _stranaA;
            }
        }
        public double stranaB
        {
            set
            {
                if (value >= 0)
                {
                    _stranaA = stranaB;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("Zaporne cislo");
                }
            }
            get
            {
                return _stranaB;
            }
        }


        public Obdelnik(double A, double B)
        {
            _stranaA = A;
            _stranaB = B;
        }

        public double Obsah()
        {
                  return _stranaA * _stranaB;
        }
        public double Obvod()
        { 
                return _stranaA * 2 + _stranaB * 2;
        }
        public double StranaA()
        {
            return _stranaA;
        }
        public double StranaB()
        {
            return _stranaB;
        }
    }
}
