﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pokusoneco
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        

        private void InputTxtBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(OutputTxtBox == null)
            {
                return;
            }

            try
            {
                double cislo = InputTxtBox.Text == "" ? 0: double.Parse(InputTxtBox.Text);
                OutputTxtBox.Text = (cislo + 10).ToString();

                InputTxtBox.Background = Brushes.White;
            }
            catch
            {
                OutputTxtBox.Text = "N/A";
                InputTxtBox.Background = Brushes.Red;
            }
        }
    }
}
