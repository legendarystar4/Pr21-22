﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace jabadabadoo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SlevaCB_Checked(object sender, RoutedEventArgs e)
        {
            if (SlevaCB.IsChecked == true)
            {
                Displayrect.Fill = Brushes.Cyan;
            }
            else
            {
                Displayrect.Fill = Brushes.Lime;
            }
        }

        private void Zapnibtn_Click(object sender, RoutedEventArgs e)
        {
            SlevaCB.IsChecked = true;
        }

        private void Vypnibtn_Click(object sender, RoutedEventArgs e)
        {
            SlevaCB.IsChecked = false;
        }
    }
}
